export class Loading extends React.Component {

    render() {

      return (
        <section class="container mt-5 text-center">
            <h1 class="mb-2">VOCA</h1>
            <p>Loading...</p>
        </section>
      );
    }
}