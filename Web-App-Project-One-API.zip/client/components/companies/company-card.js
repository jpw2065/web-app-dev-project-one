
export class CompanyCard extends React.Component {

    Capitalize(str) 
    {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }


    render() {


        return (
            <div class="card text-left mb-4 mt-4">
                <div class="card-header font-weight-bold">
                    <h4 class="mb-2 mt-2">{this.Capitalize(this.props.company.industry)} Company</h4>
                </div>
                <div class="card-body">
                    <h5 class="font-weight-normal">{this.props.company.name}</h5>
                    
                    <div class="row">
                        <div class="col-4 text-right p-0">
                            <p class="font-weight-bold pr-2">Industry: </p>
                        </div>

                        <div class="col-4 d-flex flex-row justify-content-between p-0">
                            <p>{this.props.company.industry}</p>
                            <p class="font-weight-bold pr-2">Size (People): </p>
                        </div>

                        <div class="col-4 text-left p-0">
                            <p>{this.props.company.size}</p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-4 text-right p-0">
                            <p class="font-weight-bold pr-2">Contact Name: </p>
                        </div>

                        <div class="col-4 d-flex flex-row justify-content-between p-0">
                            <p>{this.props.company.contact_name}</p>
                            <p class="font-weight-bold pr-2">Contact Phone: </p>
                        </div>

                        <div class="col-4 text-left p-0">
                            <p>{this.props.company.contact_phone}</p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-4 text-right p-0">
                            <p class="font-weight-bold pr-2">Contact Email: </p>
                        </div>

                        <div class="col-4 d-flex flex-row justify-content-between p-0">
                            <p>{this.props.company.contact_email}</p>
                        </div>
                    </div>

                    <div class="d-flex flex-row justify-content-end">
                        <a href={'/companies/' + this.props.company.id} class="btn btn-primary mr-3">Profile</a>
                        <a href={'/companies/' + this.props.company.id + '/edit'} class="btn btn-primary mr-3">Edit</a>
                    </div>
                </div>

            </div>
        );
    }
}